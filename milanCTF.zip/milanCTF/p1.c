#include<stdio.h>
int prime(int);
int main()
{
	int n,counter=0;
	scanf("%d",&n);
	int arr[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&arr[i]);
		if(prime(arr[i])==1)
			counter++;
	}

	//Sorting the array
	for(int l=0;l<n-1;l++)
        {
                for(int g=l;g<n;g++)
                {
                        if(arr[g]<arr[l])
                        {
                                int t=arr[l];
                                arr[l]=arr[g];
                                arr[g]=t;
                        }
                }
        }

	for(int l=0;l<n-1;l++)
	{
		for(int g=l;g<n;g++)
		{
			if(prime(arr[l])==0&&prime(arr[g])==1)
			{
				int t=arr[l];
				arr[l]=arr[g];
				arr[g]=t;
			}
		}
	}
	for(int l=counter;l<n-1;l++)
        {
                for(int g=l;g<n;g++)
                {
                        if(arr[g]<arr[l])
                        {
                                int t=arr[l];
                                arr[l]=arr[g];
                                arr[g]=t;
                        }
                }
        }

	for(int d=0;d<n;d++)
	{
		printf("%d ",arr[d]);
	}
	printf("\n");
	return 0;
}
int prime(int x)
{
	if(x==1)
		return(0);
	else
	{
		for(int k=2;k<x;k++)
		{
			if(x%k==0)
				return(0);
		}
	}
	return(1);
}

